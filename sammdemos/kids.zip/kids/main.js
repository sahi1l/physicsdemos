var paper;
var init=function (name,wd,ht){
    paper=Raphael(name,wd.ht);
    
}
